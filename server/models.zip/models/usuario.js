'use strict';
var sequelize = require('db');

var Usuario = sequelize.define('usuario', {
    username: sequelize.STRING,
    password: sequelize.STRING
});