'use strict';
var sequelize = require('db');


var Asociado = sequelize.define('asociado', {
    nombre: sequelize.STRING,
    apellido: sequelize.STRING,
    dni: sequelize.integer,
    sexo: sequelize.Sequelize.ENUM('Masculino', 'Femenino')
});