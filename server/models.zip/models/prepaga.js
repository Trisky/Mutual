'use strict';
var sequelize = require('db');

var Prepaga = sequelize.define('prepaga', {
    nombre: sequelize.STRING,
    precio: sequelize.BIGINT
});